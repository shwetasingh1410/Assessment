import { Component } from '@angular/core';
import { Router } from '@angular/router'; 
import { DataService } from '../common/dataService.service';

@Component({
  selector: 'screen1',
  templateUrl: './screen1.component.html',
  styleUrls: ['./screen1.component.css']
})
export class Screen1Component {
  title = 'fedexAssignment';
  constructor(private _router:Router, private dataService: DataService) {}


onSubmit(val){
    let parameterValue = val;
    this.dataService.setUrlParam(parameterValue);
    this._router.navigate(['/screen2']);
  }
}
