import { Injectable } from '@angular/core';
import { HttpClient} from "@angular/common/http";
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class DataService {
    param: string = '';
    craigslisturl: string = 'https://toronto.craigslist.org';

    constructor(private httpClient: HttpClient) { }

    getUrl(){
        return this.craigslisturl;
    }

    setUrlParam(param){
        this.craigslisturl = `https://toronto.craigslist.org/search/hhh?query=${param}&sort=rel`;
    }

    getSearchResults(){
        const headerDict = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Access-Control-Allow-Headers': 'Content-Type',
            }
        const requestOptions = {headers: new HttpHeaders(headerDict)};
        return this.httpClient.get(this.craigslisturl, requestOptions)
    }
}