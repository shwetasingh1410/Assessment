import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Screen1Component } from '../screen1/screen1.component';

describe('Screen1Component', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        Screen1Component
      ],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(Screen1Component);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

//   it(`should have as input box 'searchText'`, () => {
//     const fixture = TestBed.createComponent(Screen1Component);
//     const app = fixture.componentInstance;
//     expect(app.val).toEqual('searchText');
//   });
//     it(`should have as search button box 'Submit'`, () => {
//     const fixture = TestBed.createComponent(Screen1Component);
//     const app = fixture.componentInstance;
//     expect(app.title).toEqual('Submit');
//   });
});
