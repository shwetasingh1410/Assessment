import { Component, OnInit, AfterContentInit } from '@angular/core';
import { DataService } from '../common/dataService.service';

@Component({
  selector: 'screen2',
  templateUrl: './screen2.component.html',
  styleUrls: ['./screen2.component.css']
})
export class Screen2Component implements OnInit, AfterContentInit{
    requestUrl;
    title = 'fedexAssignment';
    data:any;
   columnDefs = [
        {field: 'Name' },
        {field: 'Price' }
    ];

    rowData = [
        { Name: 'Toyota', Price: 35000 },
        { Name: 'Ford', Price: 32000 },
        { Name: 'Porsche', Price: 72000 }
    ];
    constructor(private dataService: DataService) {}
    
    ngOnInit(){
      this.requestUrl = this.dataService.getUrl();
    }
    ngAfterContentInit(){
    this.dataService.getSearchResults().subscribe((data)=>{
      console.log(data);
    });
    }
}
